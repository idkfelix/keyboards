# Teclados Artesanais

Este guia não irá comentar sobre teclados artesanais. Confira nossa lista de
[micro-controladores recomendados](Officially_Supported_Microcontrollers.md) e
siga o incrível guia sobre o assunto[aqui](https://docs.qmk.fm/#/hand_wire).
Este guia pode ser acompanhado até a parte de configurar o firmware. Depois de
configurar o teclado físico, você pode remeter a nosso guia de porte
[aqui](porting_to_kmk.md).
